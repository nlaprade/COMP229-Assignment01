const express = require("express");
const app = express();

// Using to view public folder
app.use(express.static("public"));

// View engine for ejs
app.set("view engine", "ejs");

// Redirect URLs
app.use(express.urlencoded({ extended: true }));

app.get("/", function(req, res)
    {
        console.log("home page");
        res.render("homepage");
    });

app.get("/about_me", function(req, res)
    {
        console.log("about me");
        res.render("aboutme");
    });

app.get("/services", function(req, res)
    {
        console.log("services");
        res.render("services");
    });
    
app.get("/contact_me", function(req, res)
    {
        console.log("contact me");
        res.render("contactme");
    });

app.get("/projects", function(req, res)
    {
        console.log("projects");

        //Projects List
        const projectsList = [
            {title: "BMI Calculator Windows App", 
            link: "https://github.com/nlaprade/comp123_assignment04/tree/main/BMICalculator",
            image: "/images/calculator.png",
            description: "A BMI calculator Windows App created in Semester 2; my first introduction to Windows App development."},
            {title: "Random Lottery Picker", 
            link: "https://github.com/nlaprade/COMP228_Lotto",
            image: "/images/gambling.png",
            description: "A simulator designed to mimic a lottery system, utilizing JOptionPane for its interface to select random numbers."},
            {title: "Whack a Rat", 
            link: "https://github.com/nlaprade/WhackARat",
            image: "/images/rat.png",
            description: "An HTML browser game inspired by Whack-A-Mole, featuring my girlfriend's cat as the mascot in place of the traditional mole."}
        ]
        res.render("projects", {projects: projectsList});
    });

app.get("/ref", function(req, res)
    {
        res.render("ref");
    });

app.post('/submit-contact', (req, res) => 
    {
        // have this code for future data recording for the contact-me page
        const firstName = req.body.firstName;
        const lastName = req.body.lastName;
        const phoneNumber = req.body.phoneNumber;
        const message = req.body.message;
        
        res.redirect('/');
    });

app.get("*", function(req, res)
    // "*" Is for 404 not found routes
    {
        res.send("404 Not Found");
    })

app.listen(3000, () => console.log("NodeJS Web Application is working."));